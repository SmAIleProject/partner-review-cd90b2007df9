Ce complément contient uniquement les fichiers Word et PowerPoint traduits. Les traductions provisoires doivent être relues par les partenaires. Les images intégrées restent inchangées. Téléchargez les pièces jointes originales en anglais pour les autres PDF, images et vidéos.

scenario_storytelling_13-16_attachments.zip

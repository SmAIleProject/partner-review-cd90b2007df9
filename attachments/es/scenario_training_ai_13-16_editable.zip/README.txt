Este complemento contiene únicamente los archivos Word y PowerPoint traducidos. Los socios deben revisar las traducciones provisionales. Las imágenes integradas permanecen sin cambios. Descargue el paquete original de anexos en inglés para obtener los demás PDF, imágenes y vídeos.

scenario_training_ai_13-16_attachments.zip

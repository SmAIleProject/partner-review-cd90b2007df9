Este suplemento contém apenas os ficheiros Word e PowerPoint traduzidos. Os parceiros devem rever as traduções provisórias. As imagens incorporadas permanecem inalteradas. Descarregue o pacote original de anexos em inglês para obter os restantes PDF, imagens e vídeos.

scenario_bite_future_8-12_attachments.zip

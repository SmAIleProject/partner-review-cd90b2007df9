Ovaj dodatak sadrži samo prevedene datoteke Word i PowerPoint. Projektni partneri trebaju provjeriti radne prijevode. Slike unutar dokumenata ostaju nepromijenjene. Ostali PDF dokumenti, slike i videozapisi dostupni su u izvornom paketu priloga na engleskom.

scenario_training_ai_13-16_attachments.zip
